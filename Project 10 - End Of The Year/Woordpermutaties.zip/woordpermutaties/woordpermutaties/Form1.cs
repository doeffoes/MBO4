﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace woordpermutaties
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void combi_Click(object sender, EventArgs e)
        {
            string[] woorden = { text1.Text, text2.Text, text3.Text, text4.Text, };
            listBox1.Items.Add(woorden[0] + " " + woorden[1] + " " + woorden[2] + " " + woorden[3]);
            listBox1.Items.Add(woorden[1] + " " + woorden[2] + " " + woorden[3] + " " + woorden[0]);
            listBox1.Items.Add(woorden[2] + " " + woorden[3] + " " + woorden[0] + " " + woorden[1]);
            listBox1.Items.Add(woorden[3] + " " + woorden[0] + " " + woorden[1] + " " + woorden[2]);
        }
    }
}
