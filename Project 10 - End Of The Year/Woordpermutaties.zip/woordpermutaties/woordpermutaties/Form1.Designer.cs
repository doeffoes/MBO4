﻿
namespace woordpermutaties
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.title = new System.Windows.Forms.Label();
            this.text1 = new System.Windows.Forms.TextBox();
            this.num1 = new System.Windows.Forms.Label();
            this.num2 = new System.Windows.Forms.Label();
            this.text2 = new System.Windows.Forms.TextBox();
            this.num3 = new System.Windows.Forms.Label();
            this.text3 = new System.Windows.Forms.TextBox();
            this.num4 = new System.Windows.Forms.Label();
            this.text4 = new System.Windows.Forms.TextBox();
            this.combi = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(96, 13);
            this.title.TabIndex = 0;
            this.title.Text = "Voer 4 woorden in:";
            // 
            // text1
            // 
            this.text1.Location = new System.Drawing.Point(34, 31);
            this.text1.Name = "text1";
            this.text1.Size = new System.Drawing.Size(100, 20);
            this.text1.TabIndex = 1;
            // 
            // num1
            // 
            this.num1.AutoSize = true;
            this.num1.Location = new System.Drawing.Point(12, 34);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(16, 13);
            this.num1.TabIndex = 2;
            this.num1.Text = "1:";
            // 
            // num2
            // 
            this.num2.AutoSize = true;
            this.num2.Location = new System.Drawing.Point(12, 60);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(16, 13);
            this.num2.TabIndex = 4;
            this.num2.Text = "2:";
            // 
            // text2
            // 
            this.text2.Location = new System.Drawing.Point(34, 57);
            this.text2.Name = "text2";
            this.text2.Size = new System.Drawing.Size(100, 20);
            this.text2.TabIndex = 3;
            // 
            // num3
            // 
            this.num3.AutoSize = true;
            this.num3.Location = new System.Drawing.Point(12, 86);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(16, 13);
            this.num3.TabIndex = 6;
            this.num3.Text = "3:";
            // 
            // text3
            // 
            this.text3.Location = new System.Drawing.Point(34, 83);
            this.text3.Name = "text3";
            this.text3.Size = new System.Drawing.Size(100, 20);
            this.text3.TabIndex = 5;
            // 
            // num4
            // 
            this.num4.AutoSize = true;
            this.num4.Location = new System.Drawing.Point(12, 112);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(16, 13);
            this.num4.TabIndex = 8;
            this.num4.Text = "4:";
            // 
            // text4
            // 
            this.text4.Location = new System.Drawing.Point(34, 109);
            this.text4.Name = "text4";
            this.text4.Size = new System.Drawing.Size(100, 20);
            this.text4.TabIndex = 7;
            // 
            // combi
            // 
            this.combi.Location = new System.Drawing.Point(12, 135);
            this.combi.Name = "combi";
            this.combi.Size = new System.Drawing.Size(139, 23);
            this.combi.TabIndex = 9;
            this.combi.Text = "Laat combinaties zien!";
            this.combi.UseVisualStyleBackColor = true;
            this.combi.Click += new System.EventHandler(this.combi_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 188);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(139, 108);
            this.listBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 172);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Mogelijke combinaties:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(169, 305);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.combi);
            this.Controls.Add(this.num4);
            this.Controls.Add(this.text4);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.text3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.text2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.text1);
            this.Controls.Add(this.title);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.TextBox text1;
        private System.Windows.Forms.Label num1;
        private System.Windows.Forms.Label num2;
        private System.Windows.Forms.TextBox text2;
        private System.Windows.Forms.Label num3;
        private System.Windows.Forms.TextBox text3;
        private System.Windows.Forms.Label num4;
        private System.Windows.Forms.TextBox text4;
        private System.Windows.Forms.Button combi;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
    }
}

